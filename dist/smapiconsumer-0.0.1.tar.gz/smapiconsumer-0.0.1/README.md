# Example Package

A simple example package for consuming social media api. 

### Installation
1. Clone repository
2. Navigate to ./src folder
3. Execute process_pages.py

### Usage

